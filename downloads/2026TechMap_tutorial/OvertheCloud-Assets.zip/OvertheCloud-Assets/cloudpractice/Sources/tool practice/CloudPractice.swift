import Foundation

/// Bundle for the tool practice project
public let cloudpracticeBundle = Bundle.module
